#include <QCoreApplication>
#include <QtDBus>

#define SERVICE_NAME  "qt-dev.com"
#define OBJECT_PATH   "/korea/mydbus"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QDBusConnection session = QDBusConnection::sessionBus();

    if (!session.isConnected()) {
        qDebug("fail connect D-Bus session");
        return 1;
    }

    QDBusInterface iface(SERVICE_NAME, OBJECT_PATH, "", session);

    if (iface.isValid())
    {
        QDBusReply<QString> answer1;
        QDBusReply<QString> answer2;

        answer1 = iface.call("answer1", "Request-1");
        if (answer1.isValid())
            qDebug() << "[RESPONSE] :" << answer1.value();

        answer2 = iface.call("answer2", "Request-2");
        if (answer2.isValid())
            qDebug() << "[RESPONSE] :" << answer2.value();

        return 0;
    }

    QString err;
    err= QDBusConnection::sessionBus().lastError().message();

    qDebug() << "Error :" << err;

    return a.exec();
}
