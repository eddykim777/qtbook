#include <QCoreApplication>
#include <QtDBus>
#include <QDebug>
#include "response.h"

#define SERVICE_NAME  "qt-dev.com"
#define OBJECT_PATH   "/korea/mydbus"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QDBusConnection session = QDBusConnection::sessionBus();

    if (!session.isConnected())
    {
        qDebug("fail connect D-Bus session");
        return 1;
    }

    if (!session.registerService(SERVICE_NAME))
    {
        QString err = session.lastError().message();
        qDebug() << "Error :" << err;
        exit(1);
    }

    Response res;
    session.registerObject(OBJECT_PATH, &res,
                           QDBusConnection::ExportAllSlots);


    return a.exec();
}
