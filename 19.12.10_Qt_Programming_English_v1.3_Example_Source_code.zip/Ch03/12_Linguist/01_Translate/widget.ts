<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR">
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.ui" line="14"/>
        <source>Widget</source>
        <translation></translation>
    </message>
    <message>
        <location filename="widget.ui" line="26"/>
        <source>PushButton</source>
        <translation>버튼</translation>
    </message>
</context>
</TS>
