#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

// Basic Drawing
void Widget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter;
    painter.begin(this);

//    QPen pen(Qt::blue);

//    QPixmap pixmap(":resources/qtblog.png");
//    int w = pixmap.width();
//    int h = pixmap.height();
//    pixmap.scaled(w, h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

//    QBrush brush(pixmap);
//    painter.setBrush(brush);
//    painter.setPen(Qt::blue);
//    painter.drawRect(0, 0, w, h);

    painter.setPen(Qt::blue);
    painter.drawLine(10, 10, 100, 40);
    painter.drawRect(120, 10, 80, 80);

    QRectF rect(230.0, 10.0, 80.0, 80.0);
    painter.drawRoundedRect(rect, 20, 20);

    QPointF p1[3] = {
                    QPointF(10.0, 110.0),
                    QPointF(110.0, 110.0),
                    QPointF(110.0, 190.0)
                    };
    painter.drawPolyline(p1, 3);

    QPointF p2[3] = {
                    QPointF(120.0, 110.0),
                    QPointF(220.0, 110.0),
                    QPointF(220.0, 190.0)
                    };
    painter.drawPolygon(p2, 3);

    painter.setFont(QFont("Arial", 16));
    painter.setPen(Qt::black);
    QRect font_rect(10, 150, 520, 180);
    painter.drawText(font_rect, Qt::AlignCenter,
                     "Qt developer community (http://www.qt-dev.com)");

    painter.end();
}
