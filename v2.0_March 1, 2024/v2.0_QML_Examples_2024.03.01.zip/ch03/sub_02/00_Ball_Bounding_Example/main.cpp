#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //const QUrl url("qrc:/00_Ball_Bounding_Example/bouncing-ball1.qml");
    //const QUrl url("qrc:/00_Ball_Bounding_Example/bouncing-ball2.qml");
    //const QUrl url("qrc:/00_Ball_Bounding_Example/bouncing-ball3.qml");
    //const QUrl url("qrc:/00_Ball_Bounding_Example/bouncing-ball4.qml");
    //const QUrl url("qrc:/00_Ball_Bounding_Example/bouncing-ball5.qml");

    const QUrl url("qrc:/00_Ball_Bounding_Example/complete-bouncing-ball.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
