#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "chartitem.h"
#include "baritem.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    qmlRegisterType<ChartItem>("Shapes", 1, 0, "Chart");
    qmlRegisterType<BarItem>("Shapes", 1, 0, "Bar");

    QQmlApplicationEngine engine;
    const QUrl url("qrc:/01_ChartItem_Example/Main.qml");
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
