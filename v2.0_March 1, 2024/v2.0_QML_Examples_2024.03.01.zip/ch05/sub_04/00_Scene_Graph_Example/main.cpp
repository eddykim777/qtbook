#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "triangleitem.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    qmlRegisterType<TriangleItem>("Shapes", 1, 0, "Triangle");

    QQmlApplicationEngine engine;
    const QUrl url("qrc:/00_Scene_Graph_Example/Main.qml");
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
