#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    const QUrl url("qrc:/00_Controls/busyindicator.qml");
    //const QUrl url("qrc:/00_Controls/button.qml");
    //const QUrl url("qrc:/00_Controls/checkbox.qml");
    //const QUrl url("qrc:/00_Controls/combobox.qml");

    //const QUrl url("qrc:/00_Controls/groupbox.qml");
    //const QUrl url("qrc:/00_Controls/label.qml");
    //const QUrl url("qrc:/00_Controls/progressbar.qml");

    //const QUrl url("qrc:/00_Controls/radiobutton.qml");
    //const QUrl url("qrc:/00_Controls/slider_event.qml");
    //const QUrl url("qrc:/00_Controls/spinbox_event.qml");

    //const QUrl url("qrc:/00_Controls/switch.qml");
    //const QUrl url("qrc:/00_Controls/textarea.qml");
    //const QUrl url("qrc:/00_Controls/textfield.qml");

    engine.load(url);

    return app.exec();
}









