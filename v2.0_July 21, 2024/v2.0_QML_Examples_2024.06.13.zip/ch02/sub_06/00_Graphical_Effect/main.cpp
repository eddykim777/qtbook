#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    const QUrl url("qrc:/00_Graphical_Effect/effect1.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect2.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect3.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect4.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect5.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect6.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect7.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect8.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect_Gradient.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect9.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect10.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect11.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect12.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect13.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect14.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect15.qml");
    //const QUrl url("qrc:/00_Graphical_Effect/effect16.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
