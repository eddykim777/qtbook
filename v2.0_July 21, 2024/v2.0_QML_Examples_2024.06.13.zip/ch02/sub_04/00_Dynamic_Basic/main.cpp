#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    const QUrl url("qrc:/00_Dynamic_Basic/dynamic_main.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/dynamic_component.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/application.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/key_main.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/square.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/status.qml");
    //const QUrl url("qrc:/00_Dynamic_Basic/value_change.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
