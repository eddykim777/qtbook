#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //const QUrl url("qrc:/00_Dialog/Main.qml");
    //const QUrl url("qrc:/00_Dialog/colordialog.qml");
    //const QUrl url("qrc:/00_Dialog/filedialog.qml");
    //const QUrl url("qrc:/00_Dialog/fontdialog.qml");
    const QUrl url("qrc:/00_Dialog/messagedialog.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
