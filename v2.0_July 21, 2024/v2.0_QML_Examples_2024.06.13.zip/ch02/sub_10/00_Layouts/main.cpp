#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //const QUrl url("qrc:/00_Layouts/rowlayout.qml");
    //const QUrl url("qrc:/00_Layouts/columnlayout.qml");
    const QUrl url("qrc:/00_Layouts/gridlayout.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
