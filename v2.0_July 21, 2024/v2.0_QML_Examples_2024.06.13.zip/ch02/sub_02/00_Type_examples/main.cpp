#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    const QUrl url("qrc:/00_Type_examples/rectangle.qml");
    //const QUrl url("qrc:/00_Type_examples/image.qml");
    //const QUrl url("qrc:/00_Type_examples/ani.qml");
    //const QUrl url("qrc:/00_Type_examples/anchors.qml");
    //const QUrl url("qrc:/00_Type_examples/text_image_anchors.qml");
    //const QUrl url("qrc:/00_Type_examples/gradient.qml");

    //const QUrl url("qrc:/00_Type_examples/systempalette.qml");
    //const QUrl url("qrc:/00_Type_examples/screen.qml");
    //const QUrl url("qrc:/00_Type_examples/fontloader.qml");

    //const QUrl url("qrc:/00_Type_examples/repeater.qml");
    //const QUrl url("qrc:/00_Type_examples/transformation.qml");
    //const QUrl url("qrc:/00_Type_examples/simple_accessible.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
