#include <QGuiApplication>
#include <QQmlApplicationEngine>


int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //const QUrl url("qrc:/00_Animation_Example/numberanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/propertyanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/rotationanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/ani_event_complex.qml");
    //const QUrl url("qrc:/00_Animation_Example/behaivor.qml");
    const QUrl url("qrc:/00_Animation_Example/smoothedanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/springanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/sequentialanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/parallelanimation.qml");
    //const QUrl url("qrc:/00_Animation_Example/sequential-animation-nested.qml");
    //const QUrl url("qrc:/00_Animation_Example/easingcurve.qml");
    //const QUrl url("qrc:/00_Animation_Example/pauseanimation.qml");

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
