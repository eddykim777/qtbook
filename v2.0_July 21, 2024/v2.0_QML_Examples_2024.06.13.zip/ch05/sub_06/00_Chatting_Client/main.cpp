#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "tcpconnection.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    qmlRegisterType<TcpConnection>("TCP", 1, 0, "TcpConnection");

    QQmlApplicationEngine engine;
    const QUrl url("qrc:/00_Chatting_Client/Client.qml");
    engine.load(url);

    return app.exec();
}
