#ifndef ELLIPSEITEM_H
#define ELLIPSEITEM_H

#include <QQuickPaintedItem>

class EllipseItem : public QQuickPaintedItem
{
    Q_OBJECT
    QML_ELEMENT
public:
    EllipseItem(QQuickItem *parent = nullptr);
    void paint(QPainter *painter);

signals:

};

#endif // ELLIPSEITEM_H
