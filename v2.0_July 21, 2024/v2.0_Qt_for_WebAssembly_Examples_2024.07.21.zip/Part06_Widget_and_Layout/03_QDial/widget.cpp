#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    int xpos = 30;

    for(int i = 0 ; i < 3 ; i++, xpos += 110)
    {
        m_dial[i] = new QDial(this);
        m_dial[i]->setRange(0, 100);
        m_dial[i]->setGeometry(xpos, 30, 100, 100);
    }

    m_dial[0]->setNotchesVisible(true);

    connect(m_dial[0], SIGNAL(valueChanged(int)),
            this,      SLOT(changedData()));
}

void Widget::changedData()
{
    qDebug("QDial 1 value : %d", m_dial[0]->value());
}

Widget::~Widget() {}
