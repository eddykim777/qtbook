#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDial>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    QDial *m_dial[3];

private slots:
    void changedData();


};
#endif // WIDGET_H
