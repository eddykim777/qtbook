#include "widget.h"
#include <QComboBox>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    QComboBox *combo = new QComboBox(this);
    combo->setGeometry(50, 50, 200, 30);

    combo->addItem("Application");
    combo->addItem("Grphics");
    combo->addItem("Database");
    combo->addItem("Network");
}

Widget::~Widget() {}
