#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QThread>
#include <QPlainTextEdit>

class Producer : public QThread
{
public:
    Producer() {}
    void run() override;
};

class Consumer : public QThread
{
    Q_OBJECT
public:
    Consumer() {}
    void run() override;

signals:
    void sig_echo(QString);
};


class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    QPlainTextEdit  *m_plainText;


    Producer m_producer;
    Consumer m_consumer;

private slots:
    void slot_echo(QString);

};
#endif // WIDGET_H
