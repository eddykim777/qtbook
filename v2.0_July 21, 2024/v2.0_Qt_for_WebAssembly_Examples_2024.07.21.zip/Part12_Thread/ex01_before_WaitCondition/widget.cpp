#include "widget.h"
#include <QVBoxLayout>

int numUsed;

void Producer::run()
{
    for(int i = 0 ; i < 10 ; i++) {
        sleep(1);
        ++numUsed;
    }
}

void Consumer::run()
{
    for(int i = 0 ; i < 10 ; i++) {
        QString str = QString("numUsed : %1").arg(numUsed);
        emit sig_echo(str);
    }
}

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    m_plainText = new QPlainTextEdit(this);

    QVBoxLayout *vLay = new QVBoxLayout(this);
    vLay->addWidget(m_plainText);

    setLayout(vLay);

    m_producer.start();
    m_consumer.start();

    connect(&m_consumer, SIGNAL(sig_echo(QString)),
            this, SLOT(slot_echo(QString)));
}

void Widget::slot_echo(QString str)
{
    m_plainText->appendPlainText(str);
}

Widget::~Widget()
{
}
