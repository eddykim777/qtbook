#include "widget.h"
#include "./ui_widget.h"
#include <QFontDatabase>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    QFontDatabase::addApplicationFont(":/NanumGothic.ttf");

    ui->setupUi(this);
    connect(ui->pbtStart, SIGNAL(pressed()),
            this, SLOT(slot_pbtStart()));
    connect(ui->pbtStop, SIGNAL(pressed()),
            this, SLOT(slot_pbtStop()));
    connect(ui->pbtIsRunning, SIGNAL(pressed()),
            this, SLOT(slot_isRunning()));


    m_thread1 = new MyThread(1);
    m_thread2 = new MyThread(2);

    connect(m_thread1, SIGNAL(sig_threadMsg(QString)),
            this, SLOT(slot_threadMsg(QString)));
    connect(m_thread2, SIGNAL(sig_threadMsg(QString)),
            this, SLOT(slot_threadMsg(QString)));

    connect(m_thread1, SIGNAL(started()),
            this, SLOT(slot_thread1_started()));
    connect(m_thread1, SIGNAL(finished()),
            this, SLOT(slot_thread1_finished()));

    connect(m_thread2, SIGNAL(started()),
            this, SLOT(slot_thread2_started()));
    connect(m_thread2, SIGNAL(finished()),
            this, SLOT(slot_thread2_finished()));
}

void Widget::slot_pbtStart()
{
    ui->textEdit->clear();

    m_thread1->start();
    m_thread2->start();
}

void Widget::slot_pbtStop()
{
    m_thread1->stop();
    m_thread2->stop();
}

void Widget::slot_isRunning()
{
    if(m_thread1->isRunning())
        ui->textEdit->append("First Thread state: Running");
    else
        ui->textEdit->append("First Thread state: Stopped");

    if(m_thread2->isRunning())
        ui->textEdit->append("Second Thread state: Running");
    else
        ui->textEdit->append("Second Thread state: Stoped");
}

void Widget::slot_threadMsg(QString msg)
{
    ui->textEdit->append(msg);
}

void Widget::slot_thread1_started()
{
    ui->textEdit->append("First Thread started");
}

void Widget::slot_thread1_finished()
{
    ui->textEdit->append("First Thread Stopped");
}

void Widget::slot_thread2_started()
{
    ui->textEdit->append("Second Thread started");
}

void Widget::slot_thread2_finished()
{
    ui->textEdit->append("Second Thread Stopped");
}

Widget::~Widget()
{
    delete ui;
}
