#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "MyThread.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;

    MyThread *m_thread1;
    MyThread *m_thread2;

private slots:
    void slot_pbtStart();
    void slot_pbtStop();
    void slot_isRunning();

    void slot_threadMsg(QString);

    void slot_thread1_started();
    void slot_thread1_finished();
    void slot_thread2_started();
    void slot_thread2_finished();
};
#endif // WIDGET_H
