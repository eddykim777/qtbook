#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include <QMutex>

class MyThread : public QThread
{
    Q_OBJECT
public:
    MyThread(int num);

    QString threadMsg();

private:
    bool   m_threadStop;
    int    m_number;
    QMutex mutex;

public:
    void stop();

signals:
    void sig_threadMsg(QString);

protected:
    virtual void run();
};


#endif // MYTHREAD_H
