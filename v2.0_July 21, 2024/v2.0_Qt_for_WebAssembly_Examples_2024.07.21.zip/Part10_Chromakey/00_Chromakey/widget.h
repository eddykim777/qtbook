#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;

    QImage m_sourceImg;
    QImage m_targetImg;
    QImage m_resultImg;

    int m_imgWidth;
    int m_imgHeight;
    int m_imgSize;

    void chromakeyProcess(QImage& sourceImage,
                          QImage& targetImage,
                          QImage& resultImage);
private slots:
    void slotChromakey();
};
#endif // WIDGET_H
