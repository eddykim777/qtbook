#include "widget.h"
#include <QPainter>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("QPainter 예제");
}

// Example - 1
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    painter.setPen(Qt::blue);

    painter.drawLine(10, 10, 100, 40);
    painter.drawRect(120, 10, 80, 80);

    painter.end();
}

/*
// Example - 2
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    painter.setPen(Qt::blue);
    painter.drawLine(10, 10, 100, 40); // 선
    painter.drawRect(120, 10, 80, 80); // 사각형

    QRectF rect(230.0, 10.0, 80.0, 80.0);
    painter.drawRoundedRect(rect, 20, 20); // 둥근 사각형

    QPointF p1[3]={QPointF(10.0, 110.0), QPointF(110.0, 110.0), QPointF(110.0, 190.0)};
    painter.drawPolyline(p1, 3); // 포인트 지점을 선으로 그리기

    QPointF p2[3]={QPointF(120.0, 110.0), QPointF(220.0, 110.0), QPointF(220.0, 190.0)};
    painter.drawPolygon(p2, 3); // 포인트 지점으로 도형 그리기

    painter.setFont(QFont("Arial", 20)); // 폰트지정
    painter.setPen(Qt::black);
    QRect fontRect(10, 150, 220, 180); // 텍스트를 표시할 영역
    painter.drawText(fontRect, Qt::AlignCenter, "I love Qt.");
    painter.end();
}
*/

/*
// Example - 3
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QPen pen(Qt::blue);
    pen.setWidth(4);

    painter.setPen(pen);
    QRect rect1(10.0, 20.0, 80.0, 50);
    painter.drawEllipse(rect1);

    pen.setStyle(Qt::DashLine);
    painter.setPen(pen);

    QRect rect2(110.0, 20.0, 80.0, 50.0);
    painter.drawEllipse(rect2);

    painter.end();
}
*/


/*
// Example - 4
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QPen pen(Qt::blue);
    pen.setWidth(10);

    QPointF p1[3] = {QPointF(30.0, 80.0),QPointF(20.0, 40.0), QPointF(80.0, 60.0) };
    pen.setJoinStyle(Qt::BevelJoin);
    painter.setPen(pen);
    painter.drawPolyline(p1, 3);

    QPointF p2[3] = {QPointF(130.0, 80.0), QPointF(120.0, 40.0), QPointF(180.0, 60.0) };
    pen.setJoinStyle(Qt::MiterJoin);
    painter.setPen(pen);
    painter.drawPolyline(p2, 3);

    QPointF p3[3] = {QPointF(230.0, 80.0), QPointF(220.0, 40.0), QPointF(280.0, 60.0) };
    pen.setJoinStyle(Qt::RoundJoin);
    painter.setPen(pen);
    painter.drawPolyline(p3, 3);

    painter.end();
}
*/

/*
// Example - 5
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    painter.setBrush(QBrush(Qt::green, Qt::Dense3Pattern));
    painter.setPen(Qt::blue);
    painter.drawEllipse(10, 10, 100,100);

    painter.setBrush(Qt::NoBrush);
    painter.setPen(Qt::blue);
    painter.drawEllipse(80, 10, 100, 100);

    painter.end();
}
*/

/*
// Example - 6
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QPixmap pixmap(":/images/image.png");

    int w = pixmap.width();
    int h = pixmap.height();

    pixmap.scaled(w, h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

    QBrush brush(pixmap);
    painter.setBrush(brush);
    painter.setPen(Qt::blue);
    painter.drawRect(0, 0, w, h);

    painter.end();
}
*/

/*
// Example - 7
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QLinearGradient ling(QPointF(70, 70), QPoint( 140, 140 ) );
    ling.setColorAt(0, Qt::blue);
    ling.setColorAt(1, Qt::green);

    ling.setSpread( QGradient::PadSpread );

    QBrush brush(ling);
    painter.setBrush(brush);
    painter.drawRect(0, 0, 200, 200);

    painter.end();
}
*/

/*
// Example - 8
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QRadialGradient radg(100, 100, 50, 120, 120);

    //radg.setSpread(QGradient::PadSpread);
    //radg.setSpread(QGradient::RepeatSpread);
    radg.setSpread(QGradient::ReflectSpread);

    radg.setColorAt( 0, Qt::black );
    radg.setColorAt( 1, Qt::white );

    QBrush brush(radg);
    painter.setBrush(brush);
    painter.drawRect(0, 0, 200, 200);

    painter.end();
}
*/

/*
// Example - 9
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QImage image(":/images/image.png");

    painter.setPen(QPen(Qt::blue, 1, Qt::DashLine));
    painter.drawRect(70, 70, 100, 100);

    QTransform transform;
    transform.translate(150, 150);
    transform.rotate(45);
    transform.scale(0.5, 0.5);

    painter.setTransform(transform);
    painter.drawImage(0, 0, image);

    painter.end();
}
*/

/*
// Example - 10
void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);

    QImage image(":/images/image.png");

    painter.setPen(QPen(Qt::blue, 1, Qt::DashLine));
    painter.drawRect(0, 0, 100, 100);

    QTransform transform;
    transform.translate(50, 50);
    transform.rotate(70, Qt::YAxis);

    painter.setTransform(transform);
    painter.drawImage(0, 0, image);

    painter.end();
}
*/

Widget::~Widget()
{
}









