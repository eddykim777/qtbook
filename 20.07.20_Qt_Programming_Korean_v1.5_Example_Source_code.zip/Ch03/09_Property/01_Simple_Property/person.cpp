#include "person.h"

Person::Person(QObject *parent) : QObject(parent)
{
}


