#include "response.h"

Response::Response(QObject *parent) : QObject(parent)
{
}
